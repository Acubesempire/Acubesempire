function payWithFlutterwave(amount, item){
    FlutterwaveCheckout({
      public_key: "FLWPUBK_TEST-xxxxxxxxxxxxxxxxxx-X", // replace with your real key
      tx_ref: "hooli-tx-" + Date.now(),
      amount: amount,
      currency: "NGN",
      payment_options: "card, banktransfer, ussd",
      customer: {
        email: "customer@example.com",
        phonenumber: "08138066450",
        name: "Acubes Customer",
      },
      callback: function (data) { console.log(data); },
      customizations: {
        title: "Acubes Empire",
        description: item + " purchase",
        logo: "https://via.placeholder.com/100",
      },
    });
}